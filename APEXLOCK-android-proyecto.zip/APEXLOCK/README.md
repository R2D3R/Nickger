# APEXLOCK — proyecto Android

Juego completo en `app/src/main/assets/index.html`, dentro de un WebView a pantalla completa.

## Generar el APK (elige una)
1. **Android Studio**: File > Open > carpeta APEXLOCK. Espera el sync y usa Build > Build APK(s).
   Resultado: `app/build/outputs/apk/debug/app-debug.apk`.
2. **GitHub**: sube esta carpeta a un repositorio; la acción "Build APK" (pestaña Actions) genera el APK como artefacto descargable.

Instala el APK en el teléfono (permite "instalar apps de fuentes desconocidas"). 
Requiere Android 8.0 o superior. La fuente Pixelify Sans necesita internet; sin conexión usa una fuente monoespaciada.
